using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputManager : MonoBehaviour
{
    [Header("Component")]
    [SerializeField] private Transform mousePosDebug;
    [SerializeField] private LayerMask gridLayer;

    [SerializeField] private Enum_PlayerInput.InputKey inputKey;
    [SerializeField] private Enum_PlayerInput.InputScroll inputScroll;
    private int InputScrollNum;
    public static InputManager Instance;
    private void Awake()
    {
        if (Instance != null)
        {
            Debug.LogError("There is more than one instance!" + name);
            Destroy(this);
        }
        Instance = this;
    }
    private void Start()
    {
        mousePosDebug = Instantiate(mousePosDebug);
    }
    private void Update()
    {
        mousePosDebug.position = GetMouseWorldPosition();

        inputKey = Enum_PlayerInput.InputKey.None;

        if (Input.GetKey(KeyCode.W))
        {
            inputKey = Enum_PlayerInput.InputKey.W;
        }
        if (Input.GetKey(KeyCode.A))
        {
            inputKey = Enum_PlayerInput.InputKey.A;
        }
        if (Input.GetKey(KeyCode.S))
        {
            inputKey = Enum_PlayerInput.InputKey.S;
        }
        if (Input.GetKey(KeyCode.D))
        {
            inputKey = Enum_PlayerInput.InputKey.D;
        }
        //Debug.Log(inputKey);
        InputScrollNum = 0;
        if (Input.mouseScrollDelta.y == 1)
        {
            inputScroll = Enum_PlayerInput.InputScroll.Up;
            InputScrollNum = -1;
        }
        if (Input.mouseScrollDelta.y == -1)
        {
            inputScroll = Enum_PlayerInput.InputScroll.Down;
            InputScrollNum = 1;
        }
    }
    public Vector3 GetMouseWorldPosition()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        Physics.Raycast(ray, out RaycastHit hitinfo, float.MaxValue, gridLayer);
        //Debug.Log(hitinfo.point);
        return hitinfo.point;
        
    }
    public Enum_PlayerInput.InputKey GetInputKey()
    {
        return inputKey;
    }
    public Enum_PlayerInput.InputScroll GetInputScroll()
    {
        return inputScroll;
    }
    public int GetInputScrollNum()
    {
        return InputScrollNum;
    }
}
