using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class GridSystem <TGridObject>
{
    private int width;
    private int height;
    private int cellSize;

    private TGridObject[,] GridObjectsArray;

    public GridSystem(int width, int height, int cellSize,Func<GridSystem<TGridObject>,GridPosition,TGridObject> CreateGridObject)
    {
        this.width = width;
        this.height = height;
        this.cellSize = cellSize;

        GridObjectsArray = new TGridObject[width, height];
        for(int i = 0; i< width;i++)
        {
            for(int j =0; j< height; j++)
            {
                GridPosition gridPosition = new GridPosition(i, j);
                GridObjectsArray[i, j] = CreateGridObject(this,gridPosition);
            }
        }
    }
    public void CreateDebugGridObject(GameObject DebugPrefab,Transform Origin)
    {
        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                GridPosition gridPosition = new GridPosition(i, j);
                GameObject clone = GameObject.Instantiate(DebugPrefab, GetWorldPosition(new GridPosition(i, j)), Quaternion.identity, Origin);
                GridObject_Debug gridObject_Debug = clone.GetComponent<GridObject_Debug>();
                gridObject_Debug.SetGridObject(GetGridObject(gridPosition),clone);

            }
        }
    }




    public Vector3 GetWorldPosition(GridPosition gridPosition)
    {
        float offset = (float)cellSize/2;
        return new Vector3(gridPosition.x * cellSize + offset, 0, gridPosition.y * cellSize + offset);
    }

    public TGridObject GetGridObject(GridPosition gridPosition)
    {
        return GridObjectsArray[gridPosition.x, gridPosition.y];
    }
    public TGridObject GetGridObjectByWorldPos(Vector3 worldPos)
    {
        return GetGridObject(GetGridPosition(worldPos));
    }
    public GridPosition GetGridPosition(Vector3 worldPos)
    {
        float offset = cellSize * 0.5f;
        int x = Mathf.RoundToInt(worldPos.x - offset) / cellSize;
        int z = Mathf.RoundToInt(worldPos.z - offset) / cellSize;

        return new GridPosition(x, z);
    }

}
