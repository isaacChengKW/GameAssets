using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public struct GridPosition : IEquatable<GridPosition>
{
    public int x;
    public int y;

    public GridPosition(int x, int y)
    {
        this.x = x;
        this.y = y;
    }

    public override string ToString()
    {
        return $"x : {x} , y : {y}";
    }
    public bool Equals(GridPosition other)
    {
        return other is GridPosition gridPosition &&
            gridPosition.x == x &&
            gridPosition.y == y;
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(x, y);
    }

    public override bool Equals(object obj)
    {
        return base.Equals(obj);
    }

    public static bool operator == (GridPosition a, GridPosition b)
    {
        return a.x == b.x && a.y == b.y;
    }
    public static bool operator != (GridPosition a , GridPosition b)
    {
        return !(a == b);
    }
}
