using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridManager : MonoBehaviour
{
    [Header("Adjustable")]
    [SerializeField] private int width;
    [SerializeField] private int height;
    [SerializeField] private int cellSize;

    [Header("Component")]
    [SerializeField] private GameObject debugPrefab;
    [SerializeField] private Transform origin;

    private GridObject lastGridObject;
    private GridHexSystem<GridObject> gridSystem;

    public static GridManager Instance;
    private void Awake()
    {
        if (Instance != null)
        {
            Debug.LogError("There is more than one instance!" + name);
            Destroy(this);
        }
        Instance = this;
    }
    void Start()
    {
        gridSystem = new GridHexSystem<GridObject>(width, height, cellSize,(GridHexSystem<GridObject> g,GridPosition gridPosition) => new GridObject(gridPosition));
        gridSystem.CreateDebugGridObject(debugPrefab, origin);

        for(int i =0; i<width; i++)
        {
            for (int j =0;j<height; j++)
            {
                //gridSystem.GetGridObject(new GridPosition(i, j)).SetVisual(debugPrefab.transform);
                gridSystem.GetGridObject(new GridPosition(i, j)).HideSelected();
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        /*Debug.Log
            (gridSystem.GetGridPosition(InputManager.Instance.GetMouseWorldPosition())
            );*/
        if (lastGridObject != null)
        {
            lastGridObject.HideSelected();
        }
        lastGridObject = gridSystem.GetGridObjectByWorldPos(InputManager.Instance.GetMouseWorldPosition());
        if (lastGridObject != null)
        {
            lastGridObject.ShowSelected();
        }
        //Debug.Log(gridSystem.GetGridObjectByWorldPos(InputManager.Instance.GetMouseWorldPosition()).ToString());
        //gridSystem.GetGridObjectByWorldPos(InputManager.Instance.GetMouseWorldPosition()).ShowSelected();
    }


}
