using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enum_PlayerInput 
{
    public enum InputKey
    {
        None,
        W,
        A,
        S,
        D
    }
    public enum InputScroll
    {
        None,
        Down,
        Up
    }
}
