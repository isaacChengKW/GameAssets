using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GridObject_Debug : MonoBehaviour
{
    [SerializeField] private TextMeshPro TextDebug;
    private object gridObject;

    private GridObject gridobjectHex;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        TextDebug.text = gridObject.ToString();
    }

    public void SetGridObject(object gridObject,GameObject DebugObject)
    {
        this.gridObject = gridObject;
        gridobjectHex = gridObject as GridObject;
        gridobjectHex.SetVisual(DebugObject.transform);
    }
    public void ShowSelected() => gridobjectHex.ShowSelected();
    public void HideSelected() => gridobjectHex.HideSelected();
}
