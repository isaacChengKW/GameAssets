using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class GridObject 
{
    private GridSystem<GridObject> gridSystem;
    private GridPosition gridPosition;

    private Transform visual;

    public GridObject(GridPosition gridPosition)
    {
        //this.gridSystem = gridSystem;
        this.gridPosition = gridPosition;
    }

    public override string ToString()
    {
        return gridPosition.ToString();
    }
    public void ShowSelected()
    {
        visual.Find("SelectedHexGrid").gameObject.SetActive(true);
        //Debug.Log("Show!");
    }
    public void HideSelected()
    {
        visual.Find("SelectedHexGrid").gameObject.SetActive(false);
        //Debug.Log("Hide!");
    }
    public void SetVisual(Transform visual)
    {
        this.visual = visual;
    }
}
