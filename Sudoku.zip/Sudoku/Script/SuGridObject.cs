using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SuGridObject 
{
    private SuGridSystem suGridSystem;
    private SuGridPosition suGridPosition;

    public SuGridObject(SuGridSystem suGridSystem, SuGridPosition suGridPosition)
    {
        this.suGridSystem = suGridSystem;
        this.suGridPosition = suGridPosition;
    }

    public SuGridPosition GetSuGridPosition()
    {
        return suGridPosition;
    }
    public override string ToString()
    {
        return "x : " + suGridPosition.x + "  y : " + suGridPosition.y;
    }
}
