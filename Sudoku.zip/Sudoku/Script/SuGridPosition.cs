using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct SuGridPosition : IEquatable<SuGridPosition>
{

    public int x;
    public int y;

    public SuGridPosition(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    public bool Equals(SuGridPosition other)
    {
        return other is SuGridPosition suGridPosition &&
        x == suGridPosition.x &&
        y == suGridPosition.y;
    }

    public override bool Equals(object obj)
    {
        return base.Equals(obj);
    }

    public override int GetHashCode()
    {
        return base.GetHashCode();
    }

    public override string ToString()
    {
        return "x : " + x + " y : " + y;
    }

    public static bool operator == (SuGridPosition a, SuGridPosition b)
    {
        return a.x == b.x && a.y == b.y;
    }
    public static bool operator !=(SuGridPosition a, SuGridPosition b)
    {
        return !(a == b);
    }
}
