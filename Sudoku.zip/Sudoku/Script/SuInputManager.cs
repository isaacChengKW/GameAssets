using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class SuInputManager : MonoBehaviour
{
    [SerializeField] private bool canInput;

    private int InputNum;
    private KeyCode[] keyCodes = new KeyCode[] { KeyCode.Alpha1, KeyCode.Alpha2, KeyCode.Alpha3, KeyCode.Alpha4, KeyCode.Alpha5, KeyCode.Alpha6, KeyCode.Alpha7, KeyCode.Alpha8, KeyCode.Alpha9 };
    public static SuInputManager Instance;
    private void Awake()
    {
        if (Instance != null)
        {
            Debug.LogError("There is more than one Instance " + name);
            Destroy(this);
        }
        Instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        GetUserInput();
    }

    private void GetUserInput()
    {
        if (!canInput) return;
        foreach(var v in keyCodes)
        {
            if (Input.GetKeyDown(v))
            {
                int lastindex = v.ToString().Length - 1;
                InputNum = (int)char.GetNumericValue( v.ToString()[lastindex]);
                SuGridManager.Instance.OnUserUpdateSlotNum(InputNum);
            }
        }
        
    }
    public void SetUserCanInput(bool caninput)
    {
        this.canInput = caninput;
    }
}
