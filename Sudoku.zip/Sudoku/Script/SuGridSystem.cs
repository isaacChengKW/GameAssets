using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SuGridSystem 
{
    private int width;
    private int height;
    private int cellSize;
    private SuGridObject[,] suGridObjectArray;
    private SuNumberSlot[,] suNumberSlotArray;
    private int[] fillinFirstNum = { 1, 4, 7, 2, 5, 8, 3, 6, 9 };

    public SuGridSystem(int width, int height, int cellSize)
    {
        this.width = width;
        this.height = height;
        this.cellSize = cellSize;

        suGridObjectArray = new SuGridObject[width, height];
        for(int i =0; i < width; i++)
        {
            for (int j = 0; j<height; j++)
            {
                SuGridPosition suGridPosition = new SuGridPosition(i, j);
                suGridObjectArray[i, j] = new SuGridObject(this, suGridPosition);
            }
        }
    }
    public Vector2 GetWorldPosition(SuGridPosition suGridPosition)
    {
        return new Vector2(suGridPosition.x * cellSize, suGridPosition.y * cellSize);
    }
    public SuGridObject GetSuGridObject(SuGridPosition suGridPosition)
    {
        return suGridObjectArray[suGridPosition.x, suGridPosition.y];
    }
    public void CreateDebugObject(GameObject DebugObject,Transform Origin)
    {
        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                SuGridPosition suGridPosition = new SuGridPosition(i, j);
                Vector2 offSet = new Vector2(-150, -150);
                GameObject Clone = GameObject.Instantiate(DebugObject, new Vector2(Origin.position.x,Origin.position.y) + GetWorldPosition(suGridPosition) + offSet , Quaternion.identity,Origin);
                SuGridDebugObject suGridDebugObject = Clone.GetComponent<SuGridDebugObject>();
                suGridDebugObject.SetGridObject(GetSuGridObject(suGridPosition));

            }
        }
    }

    public void CreateNumberSlot(GameObject DebugObject, Transform Origin)
    {
        suNumberSlotArray = new SuNumberSlot[width, height];
        for (int i = 0; i < width; i++)
        {
            int fillInNum = fillinFirstNum[i];
            for (int j = 0; j < height; j++)
            {
                SuGridPosition suGridPosition = new SuGridPosition(i, j);
                Vector2 offSet = new Vector2(-150, -150);
                GameObject Clone = GameObject.Instantiate(DebugObject, new Vector2(Origin.position.x, Origin.position.y) + GetWorldPosition(suGridPosition) + offSet, Quaternion.identity, Origin);

                SuNumberSlot suNumberSlot = Clone.GetComponent<SuNumberSlot>();

                suNumberSlotArray[i, j] = suNumberSlot;

                suNumberSlot.SetSuGridObject(GetSuGridObject(suGridPosition));

                //int fillInNum = (int)char.GetNumericValue((i + j+1).ToString()[(i+j).ToString().Length-1]);
                if (fillInNum > 9)
                {
                    fillInNum -= 9;
                }
                AutoFillInNum(suNumberSlot, fillInNum);
                fillInNum ++ ;

            }
        }
        //Debug.Log(suNumberSlotArray[0, 5].GetInputNum());
    }
    public void ClearNumberSlotNum()
    {
        
        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                SuNumberSlot suNumberSlot = suNumberSlotArray[i, j];

                suNumberSlot.SetInputNum(0);
                suNumberSlot.UpdateText();
            }
        }
        //Debug.Log("ClearAllSuNumberSlot!");
    }
    private void AutoFillInNum(SuNumberSlot suNumberSlot,int n)
    {
        suNumberSlot.FillinNumAndUpdateText(n);
    }
    public SuNumberSlot[,] GetSuNumberSlot()
    {
        return suNumberSlotArray;
    }
    public int GetWidth()
    {
        return width;
    }
    public int GetHeight()
    {
        return height;
    }
}
