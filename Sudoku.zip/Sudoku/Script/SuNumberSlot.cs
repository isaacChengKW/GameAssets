using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class SuNumberSlot : MonoBehaviour
{

    [Header("Component")]
    [SerializeField] private TextMeshProUGUI NumberText;
    [SerializeField] private GameObject Visual_SelectedSlot;

    private bool SelectedSlot;
    private int InputNum;
    private Button button;
    private SuGridObject suGridObject;


    // Start is called before the first frame update
    void Start()
    {
        button = GetComponent<Button>();
        button.onClick.AddListener(ButtonOnClickCallBack);
        UpdateText();

        SuGridManager.Instance.AddSlotToList(this);
    }

    // Update is called once per frame
    void Update()
    {

    }
    public void SetSuGridObject(SuGridObject suGridObject)
    {
        this.suGridObject = suGridObject;
    }
    public void UpdateText()
    {
        if (InputNum == 0)
        {
            NumberText.text = "";

        }
        else
        {
            NumberText.text = InputNum.ToString();
        }
    }
    public void SetInputNum(int n)
    {
        InputNum = n;
    }
    public void SetSelectSlot()
    {
        SelectedSlot = true;
        ShowSelectVisual();
    }
    public void RemoveSelectSlot()
    {
        SelectedSlot = false;
        HideSelectVisual();
    }
    //AutoFilling
    public void FillinNumAndUpdateText(int n)
    {
        InputNum = n;

        UpdateText();
    }
    private void ButtonOnClickCallBack()
    {
        //Debug.Log("Click!! " + suGridObject.GetSuGridPosition().ToString());
        SuGridManager.Instance.OnSelectedSlotChange(this);
    }
    private void ShowSelectVisual()
    {
        Visual_SelectedSlot.SetActive(true);
    }
    private void HideSelectVisual()
    {
        Visual_SelectedSlot.SetActive(false);
    }
    public int GetInputNum()
    {
        return InputNum;
    }
}
