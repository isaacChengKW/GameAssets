using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class SuEndGameCheckManager : MonoBehaviour
{
    private SuGridSystem suGridSystem;
    public static SuEndGameCheckManager Instance;
    private int rowCheckAns = 362880;
    private int[] colCheck;
    private int[] gridCheck;
    private void Awake()
    {
        if (Instance != null)
        {
            Debug.LogError("There is more than one Instance " + name);
            Destroy(this);
        }
        Instance = this;
    }
    private void Start()
    {
        GetSuGridSystem();
        colCheck = new int[suGridSystem.GetHeight()];
        gridCheck = new int[suGridSystem.GetHeight()];
    }
    private void GetSuGridSystem()
    {
        suGridSystem = SuGridManager.Instance.GetGridSystem();
    }
    public void Button_EndGameCheckingCallBack()
    {
        if (EndGameCheck())
        {
            Debug.Log("Correct");
        }
        else
        {
            Debug.Log("InCorrect");
        }
    }
    public bool EndGameCheck()
    {
        Array.Clear(colCheck,0,colCheck.Length);
        Array.Clear(gridCheck,0,colCheck.Length);
        for (int i =0; i < suGridSystem.GetWidth(); i++)
        {
            //Rowcheck
            int rowcheck = 1;
            for(int j = 0; j< suGridSystem.GetHeight(); j++)
            {
                //Rowcheck
                rowcheck *= suGridSystem.GetSuNumberSlot()[i, j].GetInputNum();

                //ColCheck
                colCheck[j] += suGridSystem.GetSuNumberSlot()[i, j].GetInputNum();

                //GridCheck
                if (i < 3 )
                {
                    gridCheck[j / 3 ] += suGridSystem.GetSuNumberSlot()[i, j].GetInputNum();
                    //Debug.Log(gridCheck[j / 3] + " " + j);
                }
                else if (i < 6)
                {
                    gridCheck[j / 3 + 3] += suGridSystem.GetSuNumberSlot()[i, j].GetInputNum();
                }
                else
                {
                    gridCheck[j / 3 + 6] += suGridSystem.GetSuNumberSlot()[i, j].GetInputNum();
                }
            }
            //Rowcheck
            if (rowcheck != rowCheckAns)
            {
                return false;
            }

        }
        //ColCheck
        foreach (int n in colCheck)
        {
            if (n != 45) return false;
        }
        //GridCheck
        foreach(int n in gridCheck)
        {
            //Debug.Log(n);
            if (n != 45) return false;
        }


        return true;
    }
}
