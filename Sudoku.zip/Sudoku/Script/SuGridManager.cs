using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class SuGridManager : MonoBehaviour
{
    [Header("Toggle")]
    [SerializeField] private bool ShowDebugObject;

    [Header("Component")]
    [SerializeField] private Transform origin;
    [SerializeField] private GameObject NumberSlotPrefab;

    [SerializeField] private GameObject debugPrefab;

    private SuGridSystem suGridSystem;

    private List<SuNumberSlot> suNumberSlotList;
    private SuNumberSlot CurrentSelectedSlot;
    private SuNumberSlot PreviousSelectedSlot;

    private EventHandler OnSlotSelected;


    public static SuGridManager Instance;
    private void Awake()
    {
        if (Instance != null)
        {
            Debug.LogError("There is more than one Instance " + name);
            Destroy(this);
        }
        Instance = this;
        suNumberSlotList = new List<SuNumberSlot>();
        suGridSystem = new SuGridSystem(9, 9, 40);
    }
    // Start is called before the first frame update
    void Start()
    {
        CreateNumberSlot();
        ShowDebugOBJ();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void ShowDebugOBJ()
    {
        if (ShowDebugObject)
        suGridSystem.CreateDebugObject(debugPrefab, origin);
    }
    private void CreateNumberSlot()
    {
        suGridSystem.CreateNumberSlot(NumberSlotPrefab, origin);

    }
    public void AddSlotToList(SuNumberSlot slot)
    {
        suNumberSlotList.Add(slot);
    }
    public void OnSelectedSlotChange(SuNumberSlot slot)
    {
        UpdateSelectedSlot(slot);
        UpdateSelectedSlotVisual();
        OnSlotSelected?.Invoke(this, EventArgs.Empty);
    }
    public void OnUserUpdateSlotNum(int n)
    {
        //Update Logic
        UpdateCurrentSlotNum(n);

        //Update Action
        UpdateCurrentSlotNumText();

        //RemoveCurrentSlot
        RemoveCurrentSlot();
        SuInputManager.Instance.SetUserCanInput(false);
    }
    private void UpdateSelectedSlot(SuNumberSlot slot)
    {
        if (CurrentSelectedSlot == null)
        {
            PreviousSelectedSlot = slot;
            CurrentSelectedSlot = slot;
        }
        else
        {
            PreviousSelectedSlot = CurrentSelectedSlot;
            CurrentSelectedSlot = slot;
        }
        SuInputManager.Instance.SetUserCanInput(true);

    }
    private void RemoveCurrentSlot()
    {
        CurrentSelectedSlot.RemoveSelectSlot();
        CurrentSelectedSlot = null;
    }
    private void UpdateSelectedSlotVisual()
    {
        PreviousSelectedSlot.RemoveSelectSlot();
        CurrentSelectedSlot.SetSelectSlot();
    }
    private void UpdateCurrentSlotNum(int n)
    {
        CurrentSelectedSlot.SetInputNum(n);
    }
    private void UpdateCurrentSlotNumText()
    {
        CurrentSelectedSlot.UpdateText();
    }

    public SuGridSystem GetGridSystem()
    {
        return suGridSystem;
    }
    public void ClearSuNumberSlotNum() => suGridSystem.ClearNumberSlotNum();
}
