using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SuGridDebugObject : MonoBehaviour
{
    private SuGridObject suGridObject;

    [SerializeField] private TextMeshProUGUI Text;

    public void SetGridObject(SuGridObject suGridObject)
    {
        this.suGridObject = suGridObject;
    }

    private void Update()
    {
        Text.text = suGridObject.ToString();
    }
}
