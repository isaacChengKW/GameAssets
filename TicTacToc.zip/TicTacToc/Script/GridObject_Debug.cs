using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GridObject_Debug : MonoBehaviour
{
    private GridObject gridobject;
    [SerializeField] private TextMeshProUGUI text;

    private void Update()
    {
        text.text = gridobject.ToString();
    }

    public void SetDebugObject(GridObject gridObject)
    {
        this.gridobject = gridObject;
    }

}
