using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridManager : MonoBehaviour
{
    [Header("Toggle")]
    [SerializeField] private bool ShowDebugObject;

    [Header("Component")]
    [SerializeField] private GameObject DebugPrefab;
    [SerializeField] private GameObject PlayObjectPrefab;
    [SerializeField] private Transform Origin;

    [SerializeField] private List<PlayObject> AllPlayObjects;
    private GridSystem gridSystem;

    public static GridManager Instance;
    private void Awake()
    {
        if (Instance!=null)
        {
            Destroy(this);
            Debug.LogError("There is more than one is instance " + name);
        }
        Instance = this;
    }
    void Start()
    {
        gridSystem = new GridSystem(3, 3, 100, Origin);
        gridSystem.CreatePlayObject(PlayObjectPrefab);
        CreateDebugObject();
    }

    public void CreateDebugObject()
    {
        if (ShowDebugObject)
        {
            gridSystem.CreateDebugObject(DebugPrefab);
            //Debug.Log("ShowDebugGrid");
        }
    }
    public void AddToPlayObjectList(PlayObject playObject)
    {
        AllPlayObjects.Add(playObject);
    }
    public void ResetGame()
    {
        foreach(PlayObject p in AllPlayObjects)
        {
            p.ResetGame();
        }
    }
    public void EndGame()
    {
        foreach (PlayObject p in AllPlayObjects)
        {
            p.DisableButton();
        }
    }
    public Vector3 GetWorldPosition(GridPosition gridPosition) => gridSystem.GetWorldPosition(gridPosition);

    public int GetGridWidth() => gridSystem.GetGridWidth();
    public int GetGridHeight() => gridSystem.GetGridHeight();

}
