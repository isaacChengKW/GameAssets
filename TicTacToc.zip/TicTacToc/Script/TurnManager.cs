using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnManager : MonoBehaviour
{
    [SerializeField]Enum_Turn.turn currentTurn;

    public static TurnManager Instance;
    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(this);
            Debug.LogError("There is more than one is instance " + name);
        }
        Instance = this;
    }

    private void Start()
    {
        currentTurn = Enum_Turn.turn.Tick;
    }
    public void NextTurn()
    {
        if (currentTurn == Enum_Turn.turn.Tick)
        {
            currentTurn = Enum_Turn.turn.Cross;
        }
        else
        {
            currentTurn = Enum_Turn.turn.Tick;
        }
        //Debug.Log(currentTurn);

    }
    public void EndGame()
    {
        currentTurn = 0;
    }
    public Enum_Turn.turn GetCurrentTurn()
    {
        return currentTurn;
    }
    public void ResetTurn()
    {
        currentTurn = Enum_Turn.turn.Tick;
    }
}
