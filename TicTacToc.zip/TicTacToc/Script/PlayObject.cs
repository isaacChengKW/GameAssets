using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayObject : MonoBehaviour
{
    [SerializeField] Enum_Turn.turn currentTurn;
    [SerializeField] private Sprite TickSprite;
    [SerializeField] private Sprite CrossSprite;
    [SerializeField] private Sprite OriginalSprite;

    private Image buttonImage;
    private Button button;
    private Color originalcolor;
    private GridObject gridObject;
    private void Start()
    {
        buttonImage = GetComponent<Image>();
        button = GetComponent<Button>();
        button.onClick.AddListener(ButtonOnclick);
        GridManager.Instance.AddToPlayObjectList(this);
        originalcolor = buttonImage.color;
    }

    public void ButtonOnclick()
    {
        currentTurn = TurnManager.Instance.GetCurrentTurn();
        //Debug.Log(currentTurn);
        UpdateObjectVisual();
        RecordSelectedPosition();
        button.enabled = false;
    }

    public void SetPlayObject(GridObject gridObject)
    {
        this.gridObject = gridObject;
    }
    //Record Selected Position
    public void RecordSelectedPosition()
    {
        CheckingManager.Instance.AddRecordToSelectedGridArray(this);
        TurnManager.Instance.NextTurn();
    }
    private void UpdateObjectVisual()
    {
        if (currentTurn == Enum_Turn.turn.Tick)
        {
            buttonImage.sprite = TickSprite;
            buttonImage.color = Color.green;
        }
        else
        {
            buttonImage.sprite = CrossSprite;
            buttonImage.color = Color.red;
        }
    }
    public Enum_Turn.turn GetCurrentTurn()
    {
        return currentTurn;
    }
    public void ResetGame()
    {
        buttonImage.sprite = OriginalSprite;
        buttonImage.color = originalcolor;
        button.enabled = true;

    }
    public void DisableButton()
    {
        button.enabled = false;
    }
    public GridPosition GetGridPosition() => gridObject.GetGridPosition();
}
