using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
public class EndGameEvent : UnityEvent<bool,bool> { }

public class CheckingManager : MonoBehaviour
{
    private List<GridPosition> SelectedTickGridArray;
    private List<GridPosition> SelectedCrossGridArray;

    private static GridPosition[] WinningGridPosition1 = {new GridPosition(0,0), new GridPosition(0, 1), new GridPosition(0, 2)};
    private static GridPosition[] WinningGridPosition2 = {new GridPosition(0,0), new GridPosition(1, 0), new GridPosition(2, 0)};
    private static GridPosition[] WinningGridPosition3 = {new GridPosition(0,0), new GridPosition(1, 1), new GridPosition(2, 2)};
    private static GridPosition[] WinningGridPosition4 = {new GridPosition(1,0), new GridPosition(1, 1), new GridPosition(1, 2)};
    private static GridPosition[] WinningGridPosition5 = {new GridPosition(2,0), new GridPosition(2, 1), new GridPosition(2, 2)};
    private static GridPosition[] WinningGridPosition6 = {new GridPosition(0,1), new GridPosition(1, 1), new GridPosition(2, 1)};
    private static GridPosition[] WinningGridPosition7 = {new GridPosition(0,2), new GridPosition(1, 2), new GridPosition(2, 2)};
    private static GridPosition[] WinningGridPosition8 = {new GridPosition(0,2), new GridPosition(1, 1), new GridPosition(2, 0)};

    private GridPosition[][] AllWinningGridPosition = {WinningGridPosition1, WinningGridPosition2, WinningGridPosition3, WinningGridPosition4, WinningGridPosition5, WinningGridPosition6, WinningGridPosition7, WinningGridPosition8};

    private bool tickWin;
    private bool draw;

    public EndGameEvent OnGameEndEvent;

    public static CheckingManager Instance;
    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(this);
            Debug.LogError("There is more than one is instance " + name);
        }
        Instance = this;
    }
    private void Start()
    {
        SelectedTickGridArray = new List<GridPosition>();
        SelectedCrossGridArray = new List<GridPosition>();
        if (OnGameEndEvent == null)
        {
            OnGameEndEvent = new EndGameEvent();
        }
        OnGameEndEvent.AddListener(OnGameEnd);

    }

    public void AddRecordToSelectedGridArray(PlayObject playObject)
    {
        if (playObject.GetCurrentTurn() == Enum_Turn.turn.Tick)
        {
            SelectedTickGridArray.Add(playObject.GetGridPosition());
        }
        else
        {
            SelectedCrossGridArray.Add(playObject.GetGridPosition());
        }
        if (SelectedCrossGridArray.Count + SelectedTickGridArray.Count >=9)
        {
            draw = true;
            OnGameEndEvent?.Invoke(tickWin,draw);
        }

        if (EndGameChecking())
        {
            Debug.Log("EndGame!!!!");
            OnGameEndEvent?.Invoke(tickWin, draw);
        }
        else
        {
            Debug.Log("Continue");
        }
    }
    private bool EndGameChecking()
    {
        foreach (var v in AllWinningGridPosition)
        {
            int tickcount = 0;
            int crosscount = 0;
            foreach (GridPosition g in v)
            {
                foreach(GridPosition p in SelectedTickGridArray)
                {
                    if (g == p)
                    {
                        tickcount++;
                    }
                    tickWin = true;
                    if (tickcount == 3) return true;

                }
                foreach (GridPosition p in SelectedCrossGridArray)
                {
                    if (g == p)
                    {
                        crosscount++;
                    }
                    tickWin = false;
                    if (crosscount == 3) return true;

                }
            }
        }
        return false;
    }
    private void OnGameEnd(bool tickWin,bool draw)
    {
        UIManager.Instance.EndGame(tickWin, draw);
        GridManager.Instance.EndGame();
    }
    public void ResetGameData()
    {
        draw = false;
        SelectedTickGridArray.Clear();
        SelectedCrossGridArray.Clear();
        TurnManager.Instance.ResetTurn();
        GridManager.Instance.ResetGame();
        UIManager.Instance.ResetGame();
    }
}
