using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridSystem 
{
    private int width;
    private int height;
    private int cellSize;
    private Transform origin;
    private GridObject[,] gridObjectsArray;

    public GridSystem(int width, int height, int cellSize,Transform origin)
    {
        this.width = width;
        this.height = height;
        this.cellSize = cellSize;
        this.origin = origin;

        gridObjectsArray = new GridObject[width,height];

        for(int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                GridPosition gridPosition = new GridPosition(i, j);
                gridObjectsArray[i, j] = new GridObject(this,gridPosition);
            }
        }
    }

    public void CreateDebugObject(GameObject DebugObject)
    {
        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                GridPosition gridPosition = new GridPosition(i, j);
                GameObject Clone =  GameObject.Instantiate(DebugObject, GetWorldPosition(gridPosition), Quaternion.identity, origin);
                GridObject_Debug gridObject_Debug = Clone.GetComponent<GridObject_Debug>();
                gridObject_Debug.SetDebugObject(GetGridObject(gridPosition));
            }
        }
    }
    public void CreatePlayObject(GameObject PlayObject)
    {
        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                GridPosition gridPosition = new GridPosition(i, j);
                GameObject Clone = GameObject.Instantiate(PlayObject, GetWorldPosition(gridPosition), Quaternion.identity, origin);
                PlayObject playObject = Clone.GetComponent<PlayObject>();
                playObject.SetPlayObject(GetGridObject(gridPosition));
            }
        }
    }
    public Vector3 GetWorldPosition(GridPosition gridPosition)
    {
        Vector2 offset = new Vector2(150, 150);
        return new Vector3(gridPosition.x * cellSize + offset.x, gridPosition.y * cellSize + offset.y, 0);
    }

    private GridObject GetGridObject(GridPosition gridPosition)
    {
        return gridObjectsArray[gridPosition.x, gridPosition.y];
    }

    public int GetGridWidth()
    {
        return width;
    }
    public int GetGridHeight()
    {
        return height;
    }
}
