using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIManager : MonoBehaviour
{
    [SerializeField] Button endGameButton;
    [SerializeField] TextMeshProUGUI endText;


    public static UIManager Instance;
    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(this);
            Debug.LogError("There is more than one is instance " + name);
        }
        Instance = this;
    }

    public void EndGame(bool tickwin,bool draw)
    {
        // Show button
        endGameButton.gameObject.SetActive(true);

        //Show text
        if (tickwin)
        {
            endText.text = "Tick WIN!!!";
        }
        else if(draw)
        {
            endText.text = "Draw!!!";
        }
        else
        {
            endText.text = "Cross WIN!!!";

        }
    }
    public void ResetGame()
    {
        endGameButton.gameObject.SetActive(false) ;

    }
}
