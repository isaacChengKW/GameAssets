using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enum_Turn 
{
    public enum turn
    {
        None,
        Tick,
        Cross
    }
}
