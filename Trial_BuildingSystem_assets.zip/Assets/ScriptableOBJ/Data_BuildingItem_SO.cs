using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[CreateAssetMenu(fileName = "BuildObject",menuName = "BuildableObject")]
public class Data_BuildingItem_SO : ScriptableObject
{
    [SerializeField] public List<BuildableObject> buildableObjectsList;

    [Serializable]
    public class BuildableObject
    {
        [field:SerializeField]
        public string itemName { get; private set; }        
        [field:SerializeField]
        public int itemID { get; private set; }        
        [field:SerializeField]
        public Vector2Int itemSize { get; private set; }
        [field:SerializeField]
        public GameObject ItemPrefab { get; private set; }
        [field:SerializeField]
        public GameObject ItemPreviewPrefab { get; private set; }

    }
}
