using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using System;
using UnityEngine.EventSystems;

public class ButtonGroup_Buildable : MonoBehaviour
{
    [Header("Component")]
    [SerializeField] private GameObject ButtonPrefab_Buildable;
    [SerializeField] private List<Button_BuildableObject> buildableButtonGroup;

    public event EventHandler OnSelectedBuildableUI;
    private Data_BuildingItem_SO data_BuildingItem_SO;

    private string selectedItemName;
    private const string selectVisualName = "SelectedVisual";

    public static ButtonGroup_Buildable Instance;
    private void Awake()
    {
        if (Instance != null)
        {
            Debug.LogError("There is more than one instance!" + name);
            Destroy(this);
        }
        Instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        data_BuildingItem_SO = BuildManager.Instance.GetData_BuildingItem_SO();
        CreateBuildableItemButtons();
    }
    private void CreateBuildableItemButtons()
    {
        foreach(Data_BuildingItem_SO.BuildableObject bd in data_BuildingItem_SO.buildableObjectsList)
        {
            //Create button and set button Info
            GameObject clone = Instantiate(ButtonPrefab_Buildable,transform);
            Button_BuildableObject buildableUI = clone.GetComponent<Button_BuildableObject>();
            buildableUI.SetButtonData(bd);
            buildableButtonGroup.Add(buildableUI);


        }
    }
    private void ShowSelectedVisual()
    {
        foreach(Button_BuildableObject button in buildableButtonGroup)
        {
            button.transform.Find(selectVisualName).gameObject.SetActive(false);

            if (selectedItemName == button.GetItemName())
            {
                button.transform.Find(selectVisualName).gameObject.SetActive(true);
            }
        }
    }
    private void SetSelectedItemName(string name)
    {
        selectedItemName = name;
        ShowSelectedVisual();
    }
    public static void ButtonOnClick_SelectedBuildableOBJUI(Data_BuildingItem_SO.BuildableObject itemdata)
    {
        //Instance Better?
        GameObject.FindObjectOfType<ButtonGroup_Buildable>().SetSelectedItemName(itemdata.itemName);
        BuildManager.Instance.SetBuildableOBJ(itemdata);
    }
    public void ClearSelectedBuildItem()
    {
        selectedItemName = "";
        ShowSelectedVisual();
    }

}
