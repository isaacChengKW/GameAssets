using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class GridObject 
{
    private GridSystem<GridObject> gridSystem;
    private GridPosition gridPosition;

    private Transform visual;
    private BuildableObject buildableObject;
    public GridObject(GridSystem<GridObject> gridSystem, GridPosition gridPosition)
    {
        this.gridSystem = gridSystem;
        this.gridPosition = gridPosition;
    }

    public override string ToString()
    {
        return gridPosition.ToString();
    }
    public void ShowSelected()
    {
        visual.Find("SelectedHexGrid").gameObject.SetActive(true);
        //Debug.Log("Show!");
    }
    public void HideSelected()
    {
        visual.Find("SelectedHexGrid").gameObject.SetActive(false);
        //Debug.Log("Hide!");
    }
    public void SetVisual(Transform visual)
    {
        this.visual = visual;
    }
    public Vector3 GetWorldPosition()
    {
        return gridSystem.GetWorldPosition(gridPosition);
    }
    public GridPosition GetGridPosition()
    {
        return gridPosition;
    }
    public void SetBuildableObject(BuildableObject buildableObject)
    {
        this.buildableObject = buildableObject;
    }
    public bool HaveBuildableObject()
    {
        return buildableObject != null;
    }
}
