using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildPreviewManager : MonoBehaviour
{
    public static BuildPreviewManager Instance;

    private bool CanShowBuildablePreview;
    private void Awake()
    {
        if (Instance != null)
        {
            Debug.LogError("There is more than one instance!" + name);
            Destroy(this);
        }
        Instance = this;
    }
    public void SetShowBuildablePreview(bool Canshow)
    {
        CanShowBuildablePreview = Canshow;
    }

    public void ShowBuildablePreview()
    {
        if (CanShowBuildablePreview)
        {

        }
    }
}
