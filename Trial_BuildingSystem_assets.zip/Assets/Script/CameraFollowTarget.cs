using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class CameraFollowTarget : MonoBehaviour
{
    [SerializeField] private float MoveSpd;
    [SerializeField] private CinemachineVirtualCamera cinemachine ;
    private List<Enum_PlayerInput.InputKey> input;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        input = InputManager.Instance.GetInputKey();
        Vector3 MoveDir = Vector3.zero;
        foreach(Enum_PlayerInput.InputKey inputk in input)
        {
            switch (inputk)
            {
                case Enum_PlayerInput.InputKey.W:
                    MoveDir += transform.forward;
                    break;
                case Enum_PlayerInput.InputKey.A:
                    MoveDir += -transform.right;
                    break;
                case Enum_PlayerInput.InputKey.S:
                    MoveDir += -transform.forward;
                    break;
                case Enum_PlayerInput.InputKey.D:
                    MoveDir += transform.right;
                    break;
                case Enum_PlayerInput.InputKey.None:
                    MoveDir = Vector3.zero;
                    break;
            }

        }
        transform.position += MoveDir.normalized * MoveSpd * Time.deltaTime;

        cinemachine.m_Lens.FieldOfView += InputManager.Instance.GetInputScrollNum();
    }
}
