using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridManager : MonoBehaviour
{
    [Header("Adjustable")]
    [SerializeField] private int width;
    [SerializeField] private int height;
    [SerializeField] private int cellSize;

    [Header("Component")]
    [SerializeField] private GameObject debugPrefab;
    [SerializeField] private Transform origin;

    private GridObject lastGridObject;
    private GridSystem<GridObject> gridSystem;

    public static GridManager Instance;
    private void Awake()
    {
        if (Instance != null)
        {
            Debug.LogError("There is more than one instance!" + name);
            Destroy(this);
        }
        Instance = this;
    }
    void Start()
    {
        gridSystem = new GridSystem<GridObject>(width, height, cellSize,(GridSystem<GridObject> g,GridPosition gridPosition) => new GridObject(g,gridPosition));
        gridSystem.CreateDebugGridObject(debugPrefab, origin);

        for(int i =0; i<width; i++)
        {
            for (int j =0;j<height; j++)
            {
                //gridSystem.GetGridObject(new GridPosition(i, j)).SetVisual(debugPrefab.transform);
                gridSystem.GetGridObject(new GridPosition(i, j)).HideSelected();
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        /*Debug.Log
            (gridSystem.GetGridPosition(InputManager.Instance.GetMouseWorldPosition())
            );*/
        if (lastGridObject != null)
        {
            lastGridObject.HideSelected();
        }
        lastGridObject = gridSystem.GetGridObjectByWorldPos(InputManager.Instance.GetMouseWorldPosition());

        if (InputManager.Instance.GetMouseWorldPosition() == Vector3.zero) lastGridObject = null;

        if (lastGridObject != null)
        {
            lastGridObject.ShowSelected();
        }
        //Debug.Log(gridSystem.GetGridObjectByWorldPos(InputManager.Instance.GetMouseWorldPosition()).ToString());
        //gridSystem.GetGridObjectByWorldPos(InputManager.Instance.GetMouseWorldPosition()).ShowSelected();
    }
    public GridObject GetLastGridObject()
    {
        return lastGridObject;
    }
    public Vector3 GetLastGridObjectWorldPos()
    {
        if (lastGridObject == null) return Vector3.zero;
        return lastGridObject.GetWorldPosition();
    }
    public int GetCellSize() => gridSystem.GetCellSize();
    public void SetLastGridObjectBuildable(BuildableObject buildableObject)
    {
        lastGridObject.SetBuildableObject(buildableObject);
        SetSelectedGridNeighbourBuildable(lastGridObject, buildableObject);
    }
    public void SetSelectedGridNeighbourBuildable(GridObject SeletecGrid, BuildableObject buildableObject)
    {
        List<GridPosition> gridPositionsList = new List<GridPosition>();
        int width = buildableObject.GetItemSize().x;
        int height = buildableObject.GetItemSize().y;

        for(int i = 0; i< width;i++)
        {
            for(int j =0; j< height; j++)
            {
                GridPosition gridPosition = lastGridObject.GetGridPosition() + new GridPosition(i, j);
                gridPositionsList.Add(gridPosition);
                gridSystem.GetGridObject(gridPosition).SetBuildableObject(buildableObject);
            }
        }

    }
    public GridObject GetGridObjectByGridPosition(GridPosition gridPosition)
    {
        return gridSystem.GetGridObject(gridPosition);
    }
}
