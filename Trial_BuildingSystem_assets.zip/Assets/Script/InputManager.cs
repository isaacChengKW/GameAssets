using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using System;

public class InputManager : MonoBehaviour
{
    [Header("Component")]
    [SerializeField] private Transform mousePosDebug;
    [SerializeField] private LayerMask gridLayer;

    [SerializeField] private List<Enum_PlayerInput.InputKey> inputKey;
    [SerializeField] private Enum_PlayerInput.InputScroll inputScroll;

    private int InputScrollNum;
    public EventHandler OnMouseClick;
    public static InputManager Instance;
    private void Awake()
    {
        if (Instance != null)
        {
            Debug.LogError("There is more than one instance!" + name);
            Destroy(this);
        }
        Instance = this;
    }
    private void Start()
    {
        mousePosDebug = Instantiate(mousePosDebug);
    }
    private void Update()
    {
        mousePosDebug.position = GetMouseWorldPosition();

        inputKey.Clear();

        if (Input.GetKey(KeyCode.W))
        {
            inputKey.Add(Enum_PlayerInput.InputKey.W);
        }
        if (Input.GetKey(KeyCode.A))
        {
            inputKey.Add(Enum_PlayerInput.InputKey.A);

        }
        if (Input.GetKey(KeyCode.S))
        {
            inputKey.Add(Enum_PlayerInput.InputKey.S);

        }
        if (Input.GetKey(KeyCode.D))
        {
            inputKey.Add(Enum_PlayerInput.InputKey.D);

            //Debug.Log(inputKey);
        }
            InputScrollNum = 0;
        if (Input.mouseScrollDelta.y == 1)
        {
            inputScroll = Enum_PlayerInput.InputScroll.Up;
            InputScrollNum = -1;
        }
        if (Input.mouseScrollDelta.y == -1)
        {
            inputScroll = Enum_PlayerInput.InputScroll.Down;
            InputScrollNum = 1;
        }

        if (Input.GetMouseButtonDown(0) && !isMouseOverUI())
        {
            OnMouseClick?.Invoke(this, EventArgs.Empty);
        }
    }
    public Vector3 GetMouseWorldPosition()
    {

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        Physics.Raycast(ray, out RaycastHit hitinfo, float.MaxValue, gridLayer);
        return hitinfo.point;
        
    }
    private bool isMouseOverUI()
    {
        return EventSystem.current.IsPointerOverGameObject();
    }
    public List<Enum_PlayerInput.InputKey> GetInputKey()
    {
        return inputKey;
    }
    public Enum_PlayerInput.InputScroll GetInputScroll()
    {
        return inputScroll;
    }
    public Transform GetMouseDebugTransform()
    {
        return mousePosDebug;
    }
    public int GetInputScrollNum()
    {
        return InputScrollNum;
    }
}
