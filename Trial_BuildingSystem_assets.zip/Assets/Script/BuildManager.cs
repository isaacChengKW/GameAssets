using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class BuildManager : MonoBehaviour
{
    [SerializeField] private Data_BuildingItem_SO data_BuildingItem_SO;
    [SerializeField] private GameObject buildableObjectPrefab;

    private bool buildableSpawned;
    private bool selectedBuildable;

    private GameObject [] currentBuildable = new GameObject [1];
    private Data_BuildingItem_SO.BuildableObject buildableOBJ;
    public static BuildManager Instance;

    //Unused variable
    //private Transform mouseTransform;
    private void Awake()
    {
        if (Instance != null)
        {
            Debug.LogError("There is more than one instance!" + name);
            Destroy(this);
        }
        Instance = this;
    }
    private void Start()
    {

        InputManager.Instance.OnMouseClick += OnMouseClick_BuildObject;
    }
    private void Update()
    {
        //Set Current Buildable Position
        if (buildableSpawned && currentBuildable[0] != null)
        {
            currentBuildable[0].transform.position = GridManager.Instance.GetLastGridObjectWorldPos();
            AdjustBuildablePosition(currentBuildable[0].transform);
        }
    }
    public Data_BuildingItem_SO GetData_BuildingItem_SO()
    {
        return data_BuildingItem_SO;
    }
    public void SetBuildableOBJ(Data_BuildingItem_SO.BuildableObject buildableObject)
    {
        if (buildableObject.itemName != "None")
        {
            this.buildableOBJ = buildableObject;
            selectedBuildable = true;
            //Spawn Buildable Preview
            SpawnBuildableObject();
        }
        else
        {

            //Destory Selected Buildable
            if (currentBuildable[0] != null)
            {
                Destroy(currentBuildable[0]);
                currentBuildable[0] = null;
            }
            RemoveSelectedBuildable();
        }
    }
    private void SpawnBuildableObject()
    {
        if (!buildableSpawned)
        {
            //Spawn seletec buildable
            GameObject clone = Instantiate(buildableObjectPrefab);
            currentBuildable[0] = clone;

            BuildableObject buildableObject = currentBuildable[0].GetComponent<BuildableObject>();
            buildableObject.SetData_BuildingItem(buildableOBJ);
        }
        else if (currentBuildable[0] != null)
        {
            //swap to other buildable
            Destroy(currentBuildable[0]);

            GameObject clone = Instantiate(buildableObjectPrefab);
            currentBuildable[0] = clone;

            BuildableObject buildableObject = currentBuildable[0].GetComponent<BuildableObject>();
            buildableObject.SetData_BuildingItem(buildableOBJ);
        }

        buildableSpawned = true;
    }
    private void BuildObject()
    {
        BuildableObject buildableObject = currentBuildable[0].GetComponent<BuildableObject>();

        //Set Object at gridPosition
        currentBuildable[0].transform.position = GridManager.Instance.GetLastGridObjectWorldPos();
        AdjustBuildablePosition(currentBuildable[0].transform);

        // remove current buildable 
        RemoveSelectedBuildable();

        // update gridobject buildable
        GridManager.Instance.SetLastGridObjectBuildable(buildableObject);

        // update visual
        buildableObject.ShowBuildObject();

        //remove SelectedUI visual
        ClearSelectedVisualUI();


    }
    private void OnMouseClick_BuildObject(object sender, EventArgs e)
    {
        // check can build
        if (!(buildableSpawned && !GridManager.Instance.GetLastGridObject().HaveBuildableObject()))
        {
            return;
        }

        // If all grid can build
        if(IsValidBuildGridList())
        {
            Debug.Log("BuildObject!");
            BuildObject();
        }
    }
    private void RemoveSelectedBuildable()
    {
        buildableOBJ = null;
        selectedBuildable = false;
        buildableSpawned = false;
        currentBuildable[0] = null;
    }
    private void ClearSelectedVisualUI()
    {
        ButtonGroup_Buildable.Instance.ClearSelectedBuildItem();
    }
    private void AdjustBuildablePosition(Transform transform)
    {
        BuildableObject buildableObject = currentBuildable[0].GetComponent<BuildableObject>();
        Vector2Int itemsize = buildableObject.GetItemSize();

        float x = GridManager.Instance.GetCellSize() * 0.5f * (itemsize.x - 1);
        float y = GridManager.Instance.GetCellSize() * 0.5f * (itemsize.y - 1);

        transform.position += new Vector3(x, 0, y);
    }
    private bool IsValidBuildGridList()
    {
        List<GridPosition> gridPositionsList = new List<GridPosition>();
        int width = buildableOBJ.itemSize.x;
        int height = buildableOBJ.itemSize.y;

        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                GridPosition gridPosition = GridManager.Instance.GetLastGridObject().GetGridPosition() + new GridPosition(i, j);
                GridObject CheckingGridObject = GridManager.Instance.GetGridObjectByGridPosition(gridPosition);
                if (CheckingGridObject.HaveBuildableObject())
                {
                    return false;
                }
            }
        }

        return true;
    }
}
