using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class GridHexSystem <TGridObject>
{
    private int width;
    private int height;
    private int cellSize;

    private const float Hex_Vertical_Offset_Mulitplier = 0.75f;

    private TGridObject[,] GridObjectsArray;

    public GridHexSystem(int width, int height, int cellSize,Func<GridHexSystem<TGridObject>,GridPosition,TGridObject> CreateGridObject)
    {
        this.width = width;
        this.height = height;
        this.cellSize = cellSize;

        GridObjectsArray = new TGridObject[width, height];
        for(int i = 0; i< width;i++)
        {
            for(int j =0; j< height; j++)
            {
                GridPosition gridPosition = new GridPosition(i, j);
                GridObjectsArray[i, j] = CreateGridObject(this,gridPosition);
            }
        }
    }
    public void CreateDebugGridObject(GameObject DebugPrefab,Transform Origin)
    {
        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                GridPosition gridPosition = new GridPosition(i, j);
                GameObject clone = GameObject.Instantiate(DebugPrefab, GetWorldPosition(new GridPosition(i, j)), Quaternion.identity, Origin);
                GridObject_Debug gridObject_Debug = clone.GetComponent<GridObject_Debug>();
                gridObject_Debug.SetGridObject(GetGridObject(gridPosition),clone);

            }
        }
    }




    public Vector3 GetWorldPosition(GridPosition gridPosition)
    {
        float offset = cellSize * 0.5f;
        return new Vector3(gridPosition.x * cellSize + offset, 0, gridPosition.y * cellSize * Hex_Vertical_Offset_Mulitplier + offset) + ((gridPosition.y % 2 ==1)? new Vector3(1,0,0) * offset:Vector3.zero);
    }

    public TGridObject GetGridObject(GridPosition gridPosition)
    {
        if (GridPositionIsOutOfBound(gridPosition)) return default (TGridObject);
        return GridObjectsArray[gridPosition.x, gridPosition.y];
    }
    public TGridObject GetGridObjectByWorldPos(Vector3 worldPos)
    {
        return GetGridObject(GetGridPosition(worldPos));
    }
    public GridPosition GetGridPosition(Vector3 worldPos)
    {
        float offset = cellSize * 0.5f;
        int x = Mathf.RoundToInt(worldPos.x - offset) / cellSize;
        int z = Mathf.RoundToInt(worldPos.z - offset) / cellSize;        
        int roughx = Mathf.RoundToInt((worldPos.x - offset) / cellSize);
        int roughz = Mathf.RoundToInt((worldPos.z - offset) / cellSize / Hex_Vertical_Offset_Mulitplier);

        Vector3Int roughxz = new Vector3Int(roughx, 0, roughz);

        bool oddRow = roughz % 2 == 1;

        List<Vector3Int> neighboutListint = new List<Vector3Int>
        {
            roughxz + new Vector3Int(-1,0,0),
            roughxz + new Vector3Int(+1,0,0),

            roughxz + new Vector3Int(oddRow? +1 : -1,0,+1),
            roughxz + new Vector3Int(0,0,+1),

            roughxz + new Vector3Int(oddRow? +1 : -1,0,-1),
            roughxz + new Vector3Int(0,0,-1),

        };

        Vector3Int cloestXZ = roughxz;

        //Debug.Log("##############");
        //Debug.Log("roughxz : " + roughxz);
        foreach(Vector3Int xz in neighboutListint)
        {

            //Debug.Log(xz);
            if (Vector3.Distance(worldPos,GetWorldPosition(new GridPosition(xz.x,xz.z))) <
                Vector3.Distance(worldPos, GetWorldPosition(new GridPosition(cloestXZ.x, cloestXZ.z))))
            {
                //Closer than Cloest
                cloestXZ = xz;
            }
        }

        x = cloestXZ.x;
        z = cloestXZ.z;


        return new GridPosition(x, z);
    }
    private bool GridPositionIsOutOfBound(GridPosition gridPosition)
    {
        return gridPosition.x >= width || gridPosition.x < 0 || gridPosition.y >= height || gridPosition.y < 0;
    }

}
