using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildableObject : MonoBehaviour
{
    [SerializeField] private Transform modelTransform;
    [SerializeField] private Transform previewTransform;

    private GameObject model;
    private GameObject preivew;
    private string itemName;
    private Data_BuildingItem_SO.BuildableObject data_BuildingItem_SO;

    public void SetData_BuildingItem(Data_BuildingItem_SO.BuildableObject data_BuildingItem_SO)
    {
        this.data_BuildingItem_SO = data_BuildingItem_SO;
        SpawnBuildable();
    }
    private void SpawnBuildable()
    {
        if (data_BuildingItem_SO.ItemPrefab != null && data_BuildingItem_SO.ItemPreviewPrefab != null)
        {
            model = Instantiate(data_BuildingItem_SO.ItemPrefab, modelTransform);
            preivew = Instantiate(data_BuildingItem_SO.ItemPreviewPrefab, previewTransform);
            SetModelVisability(preivew, model);
        }
    }
    public Transform GetModelTransform()
    {
        return modelTransform;
    }
    public Transform GetPreviewTransform()
    {
        return previewTransform;
    }
    public Vector2Int GetItemSize()
    {
        return data_BuildingItem_SO.itemSize;
    }
    /// <summary>
    /// First Para show, Second Para hide
    /// </summary>
    private void SetModelVisability(GameObject show, GameObject hide)
    {
        hide.SetActive(false);
        show.SetActive(true);
    }
    public void ShowBuildObject()
    {
        SetModelVisability(model, preivew);
    }
}
