using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Button_BuildableObject : MonoBehaviour
{
    [SerializeField] private BuildableObject buildableObject;

    private TextMeshProUGUI textUI;
    private Button button;
    private Data_BuildingItem_SO.BuildableObject data_BuildingItem_SO;
    private void Start()
    {
        button = GetComponent<Button>();
        textUI = GetComponentInChildren<TextMeshProUGUI>();
        button.onClick.AddListener(() =>
        ButtonGroup_Buildable.ButtonOnClick_SelectedBuildableOBJUI(data_BuildingItem_SO)
            );

        textUI.text = data_BuildingItem_SO.itemName;
    }
    public string GetItemName()
    {
        return data_BuildingItem_SO.itemName;
    }
    public void SetButtonData(Data_BuildingItem_SO.BuildableObject itemdata)
    {
        data_BuildingItem_SO = itemdata;
    }
}
